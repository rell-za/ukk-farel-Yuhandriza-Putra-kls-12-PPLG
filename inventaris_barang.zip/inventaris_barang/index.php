<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Manajemen Inventaris</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #e0f7fa, #fff3e0);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .navbar-dark {
            background-color: #00796b;
        }

        .navbar-brand,
        .nav-link {
            font-weight: 500;
        }

        h3 {
            color: #00695c;
        }

        .table thead {
            background-color: #00796b;
            color: white;
        }

        .btn-edit {
            background-color: rgb(46, 112, 163);
            color: white;
        }

        .btn-delete {
            background-color: rgb(196, 99, 98);
            color: white;
        }

        .btn {
            border-radius: 10px;
        }

        .table td,
        .table th {
            vertical-align: middle;
            padding: 0.55rem;
            
        }

        .table-hover tbody tr:hover {
            background-color: #f1f8e9;
        }

        .table thead {
            background-color: #00796b;
            color: white;
        }
    </style>
</head>

<body>
    <!-- Navigasi -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">📦 Inventbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Data Barang</a></li>
                    <li class="nav-item"><a class="nav-link" href="tambah.php">Tambah Barang</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategori.php">Kategori</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h3 class="mb-4">📊 Data Inventaris Barang</h3>

        <!-- Form Pencarian dan Filter -->
        <form method="get" class="row g-3 mb-4">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control" placeholder="Cari nama barang..."
                    value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>">
            </div>
            <div class="col-md-4">
                <select name="kategori" class="form-select">
                    <option value="">-- Semua Kategori --</option>
                    <?php
                    $kategori_result = mysqli_query($conn, "SELECT DISTINCT kategori_barang FROM barang");
                    while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                        $selected = (isset($_GET['kategori']) && $_GET['kategori'] == $kategori['kategori_barang']) ? "selected" : "";
                        echo "<option value='{$kategori['kategori_barang']}' $selected>{$kategori['kategori_barang']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-success w-50">Cari</button>
                <a href="index.php" class="btn btn-outline-secondary w-50">Reset</a>
            </div>
        </form>
    </div>


    <!-- Tabel Data -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover shadow-sm">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Jumlah Stok</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                $query = "SELECT * FROM barang WHERE 1";
                if (!empty($_GET['search'])) {
                    $search = $_GET['search'];
                    $query .= " AND nama_barang LIKE '%$search%'";
                }
                if (!empty($_GET['kategori'])) {
                    $kategori = $_GET['kategori'];
                    $query .= " AND kategori_barang = '$kategori'";
                }

                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) :
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                        <td><?= htmlspecialchars($row['kategori_barang']) ?></td>
                        <td><?= $row['jumlah_stok'] ?></td>
                        <td><?= "Rp" . number_format($row['harga_barang'], 0, ',', '.') ?></td>
                        <td><?= $row['tanggal_masuk'] ?></td>
                        <td>
                            <a href="edit.php?id=<?= $row['id_barang'] ?>" class="btn btn-sm btn-edit">Edit</a>
                            <a href="hapus.php?id=<?= $row['id_barang'] ?>" class="btn btn-sm btn-delete" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    </div>

    <?php
    // Setup untuk pagination
    $batas = 5; // jumlah data per halaman
    $halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
    $halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

    $where = "WHERE 1";
    if (!empty($search)) $where .= " AND nama_barang LIKE '%$search%'";
    if (!empty($kategori)) $where .= " AND kategori_barang = '$kategori'";

    // Hitung total data
    $total = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM barang $where"));
    $total_halaman = ceil($total / $batas);

    // Ambil data terbatas
    $query = "SELECT * FROM barang $where LIMIT $halaman_awal, $batas";
    $result = mysqli_query($conn, $query);
    ?>

    <!-- Pagination -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_halaman; $i++): ?>
                <li class="page-item <?= ($i == $halaman) ? 'active' : '' ?>">
                    <a class="page-link" href="?halaman=<?= $i ?>&search=<?= $search ?>&kategori=<?= $kategori ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>